/**
 * 
 */
package com.star.customizedgift.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.star.customizedgift.dto.CartDto;
import com.star.customizedgift.dto.ResponseDto;
import com.star.customizedgift.dto.UserDto;
import com.star.customizedgift.entity.Cart;
import com.star.customizedgift.entity.Customer;
import com.star.customizedgift.entity.Orders;
import com.star.customizedgift.entity.Product;
import com.star.customizedgift.entity.User;
import com.star.customizedgift.exception.GiftException;
import com.star.customizedgift.service.CartService;

/**
 * @author User1
 *
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class CartControllerTest {

	@InjectMocks
	CartController cartController;

	@Mock
	CartService cartService;

	Cart cart;
	User user;
	CartDto cartDto;
	UserDto userDto;
	Customer customer;
	Product product;
	Orders orders;
	

	@Before
	public void init() {
		cart = new Cart();
		cartDto = new CartDto();
		user = new User();
		userDto = new UserDto();
		List<UserDto> userDtos = new ArrayList<UserDto>();

		product.setProductId(1L);
		product.setProductCode("TR56");
		product.setProductDescription("Laptop Bag");
		product.setProductName("Laptop Bag");
		product.setProductPrice(3456.0);
		product.setQuantity(10);

		customer = new Customer();
		customer.setCustomerEmail("nagajyoti@hcl.com");
		customer.setCustomerId(1L);
		customer.setCustomerName("Nagajyoti");
		customer.setPhoneNumber("9980111546");

		cart.setCartId(1L);
		cart.setCustomer(customer);
		cart.setFlag(false);
		cart.setPrice(245.0);
		cart.setProduct(product);
		cart.setQuantity(5);
		cart.setType("personal");

		userDto.setEmail("nagajyoti@hcl.com");
		userDto.setMessage("Happy Birthday");
		userDto.setUserName("Nagajyoti");
		userDtos.add(userDto);

		cartDto.setCustomerId(1L);
		cartDto.setProductId(1L);
		cartDto.setQuantity(4);
		cartDto.setType("personal");
		cartDto.setUserDto(userDtos);

	}

	@Test
	public void addCart() throws GiftException {
		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatusCode(HttpStatus.OK.value());

		Mockito.when(cartService.addtoCart(cartDto)).thenReturn(responseDto);

		ResponseEntity<ResponseDto> result = cartController.addToCart(cartDto);

		assertEquals(HttpStatus.OK, result.getStatusCode());
	}

}

package com.star.customizedgift;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomisedGiftApplicationTests {

	@Test
	void contextLoads() {
	}

}

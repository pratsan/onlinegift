package com.star.customizedgift.service;

import com.star.customizedgift.dto.ResponseDto;
import com.star.customizedgift.exception.OrderNotFoundException;

public interface OrderService {
	public ResponseDto makePayment(Long cartId) throws OrderNotFoundException;
	

}

/**
 * 
 */
package com.star.customizedgift.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.customizedgift.entity.Cart;

/**
 * @author User1
 *
 */
public interface CartRepository extends JpaRepository<Cart, Long>{

}

/**
 * 
 */
package com.star.customizedgift.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author User1
 *
 */
@Setter
@Getter
public class UserDto {
	
	private String userName;
	private String email;
	private String message;

}

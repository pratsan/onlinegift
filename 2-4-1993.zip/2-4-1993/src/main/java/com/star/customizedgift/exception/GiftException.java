/**
 * 
 */
package com.star.customizedgift.exception;

/**
 * @author User1
 *
 */
public class GiftException extends Exception {

	private static final long serialVersionUID = -1747502351308293745L;

	public GiftException(String message) {
		super(message);
	}

}

package com.star.customizedgift.service;

import java.util.List;

import com.star.customizedgift.dto.ProductDto;
import com.star.customizedgift.exception.ProductException;

public interface ProductService {
	public List<ProductDto> getAllProduct() throws ProductException;

}

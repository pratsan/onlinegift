package com.star.customizedgift.exception;

public class OrderNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrderNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	} 
	

}

package com.star.customizedgift.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ProductDto {
	private Long productId;
	private String ProductName;
	private String productDescription;
	private Double productPrice;
	private String productCode;
	private int quantity;
}

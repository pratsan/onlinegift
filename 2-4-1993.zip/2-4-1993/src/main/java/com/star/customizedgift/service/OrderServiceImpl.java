package com.star.customizedgift.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.star.customizedgift.dto.MailDto;
import com.star.customizedgift.dto.ResponseDto;
import com.star.customizedgift.entity.Cart;
import com.star.customizedgift.entity.Customer;
import com.star.customizedgift.entity.Orders;
import com.star.customizedgift.entity.User;
import com.star.customizedgift.exception.OrderNotFoundException;
import com.star.customizedgift.repository.CartRepository;
import com.star.customizedgift.repository.OrdersRepository;
import com.star.customizedgift.utility.ErrorConstant;

@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	CartRepository cartRepository;
	@Autowired
	MailService mailService;

	@Autowired
	OrdersRepository ordersRepository;

	@Override
	public ResponseDto makePayment(Long cartId) throws OrderNotFoundException {
		List<MailDto> mailList = new ArrayList<>();
		Orders order = new Orders();

		Optional<Cart> cart = cartRepository.findById(cartId);
		if (!cart.isPresent())
			throw new OrderNotFoundException(ErrorConstant.ORDER_NOT_FOUND);
		List<User> user = cart.get().getUser();
		if (user.isEmpty())
			throw new OrderNotFoundException(ErrorConstant.ORDER_NOT_FOUND);
		Customer customer = cart.get().getCustomer();
		
		
		  order.setCartId(cart.get().getCartId()); order.setPurchaseDate(new Date());
		  ordersRepository.save(order);
		 
		
		user.forEach(userEmail -> {
			if (userEmail.getCartId().equals(cartId) && !cart.get().isFlag()) {
				MailDto mailDto = new MailDto();
				mailDto.setEmail(userEmail.getEmail());
				mailDto.setMessage(userEmail.getMessage());
				mailDto.setName(userEmail.getUserName());
				mailList.add(mailDto);

			}
		});

		if (mailList.isEmpty())
			throw new OrderNotFoundException(ErrorConstant.PURCHASED);

		String message = mailService.sendMail(mailList, customer.getCustomerEmail());
		System.out.println(message);
		ResponseDto dto = new ResponseDto();
		if (message.equals("order placed successfully")) {
			cart.get().setFlag(true);
			cartRepository.save(cart.get());

			dto.setMessage(ErrorConstant.ORDER_PLACED_SUCCESS);
			dto.setStatusCode(ErrorConstant.ORDER_PLACED_SUCCESS_CODE);
			return dto;
		}
		dto.setStatusCode(ErrorConstant.ORDER_PLACED_FAIL_CODE);
		dto.setMessage(ErrorConstant.ORDER_PLACED_FAIL);

		return dto;

	}
}

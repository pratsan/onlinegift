/**
 * 
 */
package com.star.customizedgift.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.star.customizedgift.utility.ErrorConstant;

/**
 * @author User1
 *
 */
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	
	  @ExceptionHandler(GiftException.class) public
	  ResponseEntity<ErrorResponse> error(GiftException ex) {
	  
	  ErrorResponse er = new ErrorResponse(); er.setMessage(ex.getMessage());
	  er.setStatus(ErrorConstant.DATA_NULL_CODE); return
	  new ResponseEntity<>(er, HttpStatus.NOT_FOUND);
	  
	  }
	 
	  @ExceptionHandler(OrderNotFoundException.class)
		public ResponseEntity<ErrorResponse> error(OrderNotFoundException ex) {

			ErrorResponse er = new ErrorResponse();
			er.setMessage(ex.getMessage());
			er.setStatus(ErrorConstant.ORDER_NOT_FOUND_CODE);
			return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

		}


		@ExceptionHandler(ProductException.class)
		public ResponseEntity<ErrorResponse> error(ProductException ex) {

			ErrorResponse er = new ErrorResponse();
			er.setMessage(ex.getMessage());
			er.setStatus(ErrorConstant.NO_RECORD_FOUND_CODE);
			return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

		}
	
}

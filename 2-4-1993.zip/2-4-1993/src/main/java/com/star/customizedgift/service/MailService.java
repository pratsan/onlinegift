package com.star.customizedgift.service;

import java.util.List;

import com.star.customizedgift.dto.MailDto;

public interface MailService {
	public String sendMail(List<MailDto> mailDto,String email);

}

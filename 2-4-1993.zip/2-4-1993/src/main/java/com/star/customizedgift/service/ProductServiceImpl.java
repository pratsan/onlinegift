package com.star.customizedgift.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.star.customizedgift.dto.ProductDto;
import com.star.customizedgift.entity.Product;
import com.star.customizedgift.exception.ProductException;
import com.star.customizedgift.repository.ProductRepository;
import com.star.customizedgift.utility.ErrorConstant;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepository productRepository;

	@Override
	public List<ProductDto> getAllProduct() throws ProductException {
		
		List<ProductDto> productDtos= new ArrayList<ProductDto>();
		
		List<Product> products = productRepository.findAll();
		if (products.isEmpty())
			throw new ProductException(ErrorConstant.NO_RECORD_FOUND);

		for (Product product : products) {
			ProductDto productDto= new ProductDto();
			BeanUtils.copyProperties(product, productDto);
			productDtos.add(productDto);
		}
		
		return productDtos;
	}
	}


package com.star.customizedgift.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.star.customizedgift.dto.MailDto;

@Component
@Service
public class MailServiceImpl implements MailService {

	@Autowired
	JavaMailSender javaMailSender;
	@Autowired
	SimpleMailMessage simpleMailMessage;

	@Override
	public String sendMail(List<MailDto> mailList, String email) {
		String message = "order placed successfully";
		try {
			mailList.forEach(user -> {
				simpleMailMessage.setText("dear"+" "+user.getName() + user.getMessage());
				simpleMailMessage.setTo(user.getEmail());
				simpleMailMessage.setBcc(email);
				javaMailSender.send(simpleMailMessage);
			});

		} catch (Exception e) {
			message = "sorry can't place order";
		}
		return message;
	}
}

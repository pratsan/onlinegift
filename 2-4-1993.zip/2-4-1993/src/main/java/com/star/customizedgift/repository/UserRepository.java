/**
 * 
 */
package com.star.customizedgift.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.customizedgift.entity.User;

/**
 * @author User1
 *
 */
public interface UserRepository extends JpaRepository<User, Long>{

}

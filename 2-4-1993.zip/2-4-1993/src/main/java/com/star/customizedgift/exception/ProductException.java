package com.star.customizedgift.exception;

public class ProductException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProductException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}

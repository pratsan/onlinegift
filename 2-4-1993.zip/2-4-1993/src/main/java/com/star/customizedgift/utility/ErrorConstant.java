/**
 * 
 */
package com.star.customizedgift.utility;

/**
 * @author User1
 *
 */
public class ErrorConstant {

	public static final String DATA_NULL = "Please provide the required data";
	public static final int DATA_NULL_CODE = 601;
	
	public static final String CUSTOMER_ID_NULL = "Customer does not exist";

	public static final String PRODICT_ID_NULL = "Selected product does not exist";

	public static final String QUANTITY_GREATER = "Quantity is greater then available stocks";
	
	public static final String USER_MISS_MATCH = "Gift quantity and user list are miss matching";

	
	public static final String CART_SUCCESS = "SuccessFully added gift to cart, proceed to buy";
	public static final int CART_SUCCESS_CODE = 604;

	public static final String GIFT_TYPE = "personal";
	public static final String GIFT_TYPE_CORPORATE = "corporate";

	public static final String PERSONAL_QUANTITY = "For personal can not select the quantity more then 3";
	
	public static final String CORPORATE_QUANTITY = "For corporate can not select the quantity less then 5";


	public static final String ORDER_NOT_FOUND = "order not found";
	public static final int ORDER_NOT_FOUND_CODE = 601;

	public static final String PURCHASED = "already purchased";
	public static final int PURCHASED_CODE = 602;
	
	
	public static final String ORDER_PLACED_SUCCESS = "order placed successfully";
	public static final int ORDER_PLACED_SUCCESS_CODE = 603;
	
	public static final String ORDER_PLACED_FAIL = "can't place order";
	public static final int ORDER_PLACED_FAIL_CODE = 604;

	public static final String NO_RECORD_FOUND = "no record found";
	public static final int NO_RECORD_FOUND_CODE = 601;

}

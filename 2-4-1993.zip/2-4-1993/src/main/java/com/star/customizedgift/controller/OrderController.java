package com.star.customizedgift.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.star.customizedgift.dto.ResponseDto;
import com.star.customizedgift.exception.OrderNotFoundException;
import com.star.customizedgift.service.MailServiceImpl;
import com.star.customizedgift.service.OrderService;

@RestController
@RequestMapping("products/")
public class OrderController {
	@Autowired
	MailServiceImpl mailServiceImpl;
	@Autowired
	OrderService orderService;

	@PutMapping("{cartId}")
	public ResponseEntity<ResponseDto> PaceOrder(@PathVariable("cartId") String cartId)
			throws NumberFormatException, OrderNotFoundException {
		return new ResponseEntity<>(orderService.makePayment(Long.parseLong(cartId)), HttpStatus.ACCEPTED);
	}
}

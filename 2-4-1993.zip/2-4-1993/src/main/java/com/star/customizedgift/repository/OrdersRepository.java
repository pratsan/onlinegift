/**
 * 
 */
package com.star.customizedgift.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.customizedgift.entity.Orders;

/**
 * @author User1
 *
 */
public interface OrdersRepository extends JpaRepository<Orders, Long>{
	
	
	

}

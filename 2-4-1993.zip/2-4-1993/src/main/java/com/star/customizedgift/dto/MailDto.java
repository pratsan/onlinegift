package com.star.customizedgift.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MailDto {
private String email;
private String message;
private String name;
}

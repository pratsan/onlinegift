/**
 * 
 */
package com.star.customizedgift.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.customizedgift.entity.Customer;

/**
 * @author User1
 *
 */
public interface CustomerRepository extends JpaRepository<Customer, Long>{
	
	public Customer findByCustomerId(Long customerId);

}

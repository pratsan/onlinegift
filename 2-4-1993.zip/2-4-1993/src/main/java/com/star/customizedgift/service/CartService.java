/**
 * 
 */
package com.star.customizedgift.service;

import com.star.customizedgift.dto.CartDto;
import com.star.customizedgift.dto.ResponseDto;
import com.star.customizedgift.exception.GiftException;

/**
 * @author User1
 *
 */
public interface CartService {

	/**
	 * @param cartDto
	 * @return
	 * @throws GiftException
	 */
	public ResponseDto addtoCart(CartDto cartDto) throws GiftException;

}

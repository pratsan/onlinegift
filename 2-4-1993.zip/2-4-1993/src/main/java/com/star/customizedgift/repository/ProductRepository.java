/**
 * 
 */
package com.star.customizedgift.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.customizedgift.entity.Product;

/**
 * @author User1
 *
 */
public interface ProductRepository extends JpaRepository<Product, Long> {
	
	public Product findByProductId(Long productId);
	

}

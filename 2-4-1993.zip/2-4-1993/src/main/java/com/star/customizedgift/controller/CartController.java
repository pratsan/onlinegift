/**
 * 
 */
package com.star.customizedgift.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.star.customizedgift.dto.CartDto;
import com.star.customizedgift.dto.ResponseDto;
import com.star.customizedgift.exception.GiftException;
import com.star.customizedgift.service.CartService;
import com.star.customizedgift.service.CartServiceImpl;

/**
 * @author User1
 *
 */

@RestController
public class CartController {

	@Autowired
	CartService cartService;

	private static final Logger LOGGER = LoggerFactory.getLogger(CartController.class);

	
	/**@author Nagajyoti
	 * @since 1-4-2020
	 * @param cartDto contains the request parameter
	 * @return the status code and message on success
	 * @throws GiftException 
	 */
	@PostMapping("/cart")
	public ResponseEntity<ResponseDto> addToCart(@RequestBody CartDto cartDto) throws GiftException {

		ResponseDto responseDto = cartService.addtoCart(cartDto);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);

	}

}

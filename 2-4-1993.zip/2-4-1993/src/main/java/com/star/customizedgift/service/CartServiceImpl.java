/**
 * 
 */
package com.star.customizedgift.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.star.customizedgift.dto.CartDto;
import com.star.customizedgift.dto.ResponseDto;
import com.star.customizedgift.dto.UserDto;
import com.star.customizedgift.entity.Cart;
import com.star.customizedgift.entity.Customer;
import com.star.customizedgift.entity.Product;
import com.star.customizedgift.entity.User;
import com.star.customizedgift.exception.GiftException;
import com.star.customizedgift.repository.CartRepository;
import com.star.customizedgift.repository.CustomerRepository;
import com.star.customizedgift.repository.ProductRepository;
import com.star.customizedgift.repository.UserRepository;
import com.star.customizedgift.utility.ErrorConstant;

/**
 * @author Nagajyoti
 *
 */
@Service
public class CartServiceImpl implements CartService {

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	ProductRepository productRepository;

	@Autowired
	CartRepository cartRepository;

	@Autowired
	UserRepository userRepository;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CartServiceImpl.class);


	@Override
	public ResponseDto addtoCart(CartDto cartDto) throws GiftException {
		
		LOGGER.debug("CartServiceImpl:addtoCart");


		ResponseDto responseDto = new ResponseDto();
		Cart cart = new Cart();
		List<User> users = new ArrayList<User>();
		List<UserDto> userDto = cartDto.getUserDto();

		if (cartDto.getCustomerId() == null || cartDto.getProductId() == null || 
				cartDto.getQuantity() == 0 || cartDto.getUserDto().isEmpty())
			throw new GiftException(ErrorConstant.DATA_NULL);

		Customer customer = customerRepository.findByCustomerId(cartDto.getCustomerId());
		Product product = productRepository.findByProductId(cartDto.getProductId());

		if (customer == null)
			throw new GiftException(ErrorConstant.CUSTOMER_ID_NULL);

		if (product == null)
			throw new GiftException(ErrorConstant.PRODICT_ID_NULL);

		if (cartDto.getQuantity() > product.getQuantity())
			throw new GiftException(ErrorConstant.QUANTITY_GREATER);

		if (userDto.size() != cartDto.getQuantity())
			throw new GiftException(ErrorConstant.USER_MISS_MATCH);

		if (cartDto.getType().equals(ErrorConstant.GIFT_TYPE) && cartDto.getQuantity() > 3)
			throw new GiftException(ErrorConstant.PERSONAL_QUANTITY);

		if (cartDto.getType().equals(ErrorConstant.GIFT_TYPE_CORPORATE) && cartDto.getQuantity() < 5)
			throw new GiftException(ErrorConstant.CORPORATE_QUANTITY);

		Double cost = product.getProductPrice() * cartDto.getQuantity();
		cart.setPrice(cost);
		cart.setCustomer(customer);
		cart.setProduct(product);
		cart.setQuantity(cartDto.getQuantity());
		cart.setType(cartDto.getType());
		cart.setFlag(false);

		Cart cartRepo = cartRepository.save(cart);

		

		for (UserDto userDto2 : userDto) {
			User user = new User();
			user.setCartId(cartRepo.getCartId());
			user.setMessage(userDto2.getMessage());
			BeanUtils.copyProperties(userDto2, user);
			users.add(user);
		}

		userRepository.saveAll(users);
		
		product.setQuantity(product.getQuantity()-cartDto.getQuantity());
		productRepository.save(product);

		responseDto.setMessage(ErrorConstant.CART_SUCCESS);
		responseDto.setStatusCode(ErrorConstant.CART_SUCCESS_CODE);

		return responseDto;
	}

}

/**
 * 
 */
package com.star.customizedgift.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * @author User1
 *
 */
@Getter
@Setter
public class CartDto {

	private Long customerId;
	private Long productId;
	private int quantity;
	private String type;

	private List<UserDto> userDto;

}

/**
 * 
 */
package com.star.customizedgift.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author User1
 *
 */
@Getter
@Setter
public class ResponseDto {
	
	private int statusCode;
	private String message;

}
